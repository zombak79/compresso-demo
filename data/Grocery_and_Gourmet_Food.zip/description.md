# Grocery and Gourmet Food

## Dataset

This example uses the Amazon Reviews 2023 Grocery and Gourmet Food dataset.

## Sparse Representation

Item metadata was embedded and compressed with a Top-k sparse autoencoder from Compresso.

## Clustering

Clusters were discovered from sparse item representations. Each cluster groups products that strongly activate a shared latent factor.
